public class Node{

	int num,step,cost,zeroPos;

	Node(int n,int s,int p){
		num=n;step=s;zeroPos=p;
		setCost();
	}
	public void setCost(){
		char brr[]={'1','2','3','4','5','6','7','8','0'};
		int c=0;
		String str=String.format("%09d", num);
		char[] a = str.toCharArray();
		for(int i=0;i<9;i++)
			if(a[i]!=brr[i])
				c++;
		cost=c+step;
	}
}