import javax.swing.*;
import java.util.Random;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageFilter;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.HashMap;
import java.util.Map;
int des=123456780;
int[][] changeId={{-1,-1,3,1},{-1,0,4,2},{-1,1,5,-1},
					{0,-1,6,4},{1,3,7,5},{2,4,8,-1},
					{3,-1,-1,7},{4,6,-1,8},{5,7,-1,-1}};
Map<Integer,Integer>mymap = new HashMap<Integer,Integer>();

Comparator<Node> OrderIsdn =  new Comparator<Node>(){
	public int compare(Node o1, Node o2) {
		// TODO Auto-generated method stub
		int numbera = o1.cost;
		int numberb = o2.cost;
		if(numberb < numbera)
		{
			return 1;
		}
		else if(numberb>numbera)
		{
			return -1;
		}
		else
		{
			return 0;
		}
		
	} 						
};

Queue<Node> que =  new PriorityQueue<Node>(11,OrderIsdn);

public void swap(char ch[],int a,int b){char c=ch[a];ch[a]=ch[b];ch[b]=c;}
public int bfsHash(int start,int zeroPos){
	char temp[];
	Node tempN=new Node(start,0,zeroPos);//����һ���ڵ� 
	que.add(tempN);//ѹ�����ȼ����� 
	mymap.put(start,1);//��ǿ�ʼ�ڵ㱻���ʹ� 
	while(!que.isEmpty()){
		tempN=que.poll();//����һ���ڵ� 
		String str=String.format("%09d",tempN.num);
		temp = str.toCharArray();
		int pos=tempN.zeroPos,k;
		for(int i=0;i<4;i++){
			if(changeId[pos][i]!=-1){
				swap(temp,pos,changeId[pos][i]);
				k=Integer.valueOf(String.valueOf(temp));
				if(k==des)return tempN.step+1;
				if(!mymap.containsKey(k)){
					Node tempM=new Node(k,tempN.step+1,changeId[pos][i]);
					que.add(tempM);//����һ���½ڵ㲢ѹ����� 
					mymap.put(k,1);
				}
				swap(temp,pos,changeId[pos][i]);
			}
			}
		}
		return que.peek().num;
}